"""SAR-pretrained segmentation backbone and matched adaptation entry point."""
import hashlib
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torchvision.models import resnet50

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))
from tta_px1 import run_one

ARMS = ("adabn_st_valid", "adabn_physa_valid")
WEIGHT_SHA = "906e4356da0ff06ce0388cba50dd4f310ba6abbee706c5303c129d8aead98082"


class FloodResNet(nn.Module):
    def __init__(self, cin=2, weights=None):
        super().__init__()
        if cin != 2:
            raise ValueError("Input order must be VV, VH")
        self.encoder = resnet50(weights=None)
        self.encoder.conv1 = nn.Conv2d(2, 64, 7, 2, 3, bias=False)
        self.encoder.fc = nn.Identity()
        if weights is not None:
            if hashlib.sha256(Path(weights).read_bytes()).hexdigest() != WEIGHT_SHA:
                raise ValueError("Unexpected encoder weights")
            self.encoder.load_state_dict(torch.load(weights, map_location="cpu", weights_only=True))
        self.lateral = nn.ModuleList(nn.Conv2d(c, 64, 1) for c in (256, 512, 1024, 2048))
        self.head = nn.Sequential(nn.Conv2d(64, 64, 3, padding=1), nn.ReLU(), nn.Conv2d(64, 2, 1))

    def forward(self, x):
        enc = self.encoder
        h = enc.maxpool(enc.relu(enc.bn1(enc.conv1(x))))
        features = []
        for layer, projection in zip((enc.layer1, enc.layer2, enc.layer3, enc.layer4), self.lateral):
            h = layer(h)
            features.append(projection(h))
        h = features.pop()
        for skip in reversed(features):
            h = skip + F.interpolate(h, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        return F.interpolate(self.head(h), size=x.shape[-2:], mode="bilinear", align_corners=False)


def paired_predictions(event, mean, std, checkpoint, seed, steps=200, device="cuda", diagnostics=None):
    # The model only receives radar, terrain and validity. Labels are scoring-only.
    blind = dict(event, lab=[np.full(r.shape[1:], 255, np.uint8) for r in event["raw"]],
                 clean=[False] * len(event["raw"]))
    outputs = {}
    for arm in ARMS:
        scores = []
        args = SimpleNamespace(seed=seed, steps=steps, model_factory=FloodResNet,
                               score_observer=lambda i, p: scores.append(p.copy()))
        run_one(arm, "V0", "fresh", blind, np.float32(mean), np.float32(std),
                args, device, str(checkpoint))
        if diagnostics is not None:
            diagnostics[arm] = args.adaptation_stats.copy()
        outputs[arm] = scores
    return outputs


if __name__ == "__main__":
    import tempfile
    import tta_px1
    torch.manual_seed(0)
    torch.set_num_threads(2)
    rng = np.random.default_rng(0)
    here = Path(__file__).resolve().parent
    model = FloodResNet(weights=here / "encoder.pth")
    with torch.no_grad():
        model.head[-1].bias[0] += 4.0
    x = torch.randn(2, 2, 64, 64)
    F.cross_entropy(model(x), (x[:, 0] > 0).long()).backward()
    assert model.encoder.conv1.weight.grad.abs().sum() > 0
    raw = rng.normal(-18, 8, (2, 64, 64)).astype("f")
    terrain = np.zeros((3, 64, 64), dtype="f")
    valid = np.ones((64, 64), dtype=bool)
    event = dict(raw=[raw], terr=[terrain], physics_terrain=[terrain],
                 radar_valid=[valid], terrain_valid=[valid])
    tta_px1.BATCH, tta_px1.CROP, tta_px1.ADABN_BATCHES = 2, 64, 2
    with tempfile.TemporaryDirectory(dir=here) as tmp:
        checkpoint = Path(tmp) / "source.pt"
        torch.save(model.state_dict(), checkpoint)
        predictions = paired_predictions(event, [-11,-18], [7,7], checkpoint, 0, steps=2, device="cpu")
        for scores in predictions.values():
            assert scores[0].shape == (64,64) and np.isfinite(scores[0]).all()
        print("Both pretrained-backbone adaptation arms passed the synthetic smoke test.")
