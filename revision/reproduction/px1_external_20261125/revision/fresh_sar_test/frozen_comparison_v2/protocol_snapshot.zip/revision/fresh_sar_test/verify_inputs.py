"""Read the event acquisition and verify per-pixel alignment before any adaptation."""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import rasterio
from rasterio.crs import CRS

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/"runtime"))
import zarr


def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(2**20),b""):
            h.update(block)
    return h.hexdigest()


def prepare(chip, base, expected):
    files = {k:base/k/(chip+suffix) for k,suffix in
             (("S1RTC","_S1RTC.zarr.zip"),("DEM","_DEM.tif"),("MASK","_annotation_flood.tif"))}
    for k,path in files.items():
        if sha(path)!=expected[k][chip]:
            raise ValueError(f"Member hash mismatch {chip} {k}")
    with zarr.ZipStore(str(files["S1RTC"]),mode="r") as store:
        group=zarr.open_consolidated(store,mode="r")
        bands=[str(x).lower() for x in group["band"][:]]
        if sorted(bands)!=["vh","vv"] or group["bands"].shape!=(4,2,256,256):
            raise ValueError(f"Unexpected axes for {chip}")
        raw=group["bands"][2].astype("f")[[bands.index("vv"),bands.index("vh")]]
        mask=~group["nan_mask"][2].astype(bool)
        slot_flag=int(group["data_mask"][2])
        x,y=group["x"][:],group["y"][:]
        crs=CRS.from_wkt(group["spatial_ref"].attrs["crs_wkt"])
        if slot_flag != 1 or not mask.any():
            raise ValueError(f"Event radar unavailable {chip}")
        times=group["time"][:]
        units=group["time"].attrs["units"]
        metadata_times=str(group.attrs.get("datetime","")).split(";")
        if units != "nanoseconds since 1970-01-01" or not np.all(np.diff(times[group["data_mask"][:].astype(bool)])>0):
            raise ValueError(f"Ambiguous time coordinate {chip}")
    with rasterio.open(files["DEM"]) as dem,rasterio.open(files["MASK"]) as labels:
        t=dem.transform
        if (dem.shape!=(256,256) or labels.shape!=dem.shape or crs!=dem.crs or labels.crs!=crs
            or not np.allclose(t,labels.transform,atol=1e-6,rtol=0) or t.b or t.d
            or not np.allclose(x,t.c+(np.arange(256)+.5)*t.a,atol=1e-6,rtol=0)
            or not np.allclose(y,t.f+(np.arange(256)+.5)*t.e,atol=1e-6,rtol=0)):
            raise ValueError(f"Grid mismatch {chip}")
        lab=labels.read(1).astype(np.int16)
        values=set(np.unique(lab).tolist())
        if not values.issubset({-1,0,1,2,255}):
            raise ValueError(f"Unrecognized label encoding {chip} {values}")
        lab=np.where((labels.read_masks(1)>0)&np.isin(lab,[0,1,2]),lab,255).astype("uint8")
    valid=mask & np.isfinite(raw).all(0) & (raw>-49.9).all(0)
    if valid.any() and np.median(raw[:,valid])>=0:
        raise ValueError(f"Radar unit ambiguity {chip}")
    raw=np.clip(raw,-50,5)
    terrain_file=HERE/"terrain"/(chip+".npz")
    with np.load(terrain_file) as a:
        terr=a["terrain"]
        hv=a["valid"]
    if terr.shape!=(3,256,256) or hv.shape!=valid.shape:
        raise ValueError(f"Terrain shape {chip}")
    dst=HERE/"prepared"/(chip+".npz")
    np.savez_compressed(dst,raw=raw,rv=valid,terr=terr,hv=hv)
    # Outcomes live separately from every adaptation input.
    lp=HERE/"prepared_labels"/(chip+".npy")
    np.save(lp,lab)
    return dict(radar_valid=int(valid.sum()),terrain_valid=int(hv.sum()),data_mask=slot_flag,
                timestamp_coordinate=int(times[2]),time_units=units,publisher_dates=metadata_times,
                bands=bands,crs=str(crs),input_sha256=sha(dst),label_sha256=sha(lp))


def main():
    selected=json.loads((HERE/"selected.json").read_text())
    split_lookup={chip:split for split in ("test","train","val")
                  for chip in (HERE/(split+".txt")).read_text().splitlines()}
    inputs=HERE/"impactmesh_inputs"
    expected={s:{k:json.loads((inputs/s/k/"verified.json").read_text())["chips"]
                 for k in ("S1RTC","DEM","MASK")} for s in ("test","train","val")}
    for folder in ("prepared","prepared_labels"):
        (HERE/folder).mkdir(exist_ok=True)
    records={}
    for chips in selected.values():
        for chip in chips:
            s=split_lookup[chip]
            records[chip]=prepare(chip,inputs/s,expected[s])
    with (HERE/"input_verification.json").open("x") as f:
        json.dump(records,f,indent=2)

if __name__=="__main__":
    main()
