"""Train on the existing Sen1Floods11 source split, in a new output location."""
import argparse
import sys
from pathlib import Path
from experiment import FloodResNet, ROOT
import train_px1

parser = argparse.ArgumentParser()
parser.add_argument("--seed", type=int, choices=(0, 1, 2), required=True)
args = parser.parse_args()
here = Path(__file__).resolve().parent
out = here / "source_models"
(out / f"SSL4EO_seed{args.seed}").mkdir(parents=True, exist_ok=False)
train_px1.UNet = lambda cin: FloodResNet(cin=cin, weights=here / "encoder.pth")
sys.argv = ["train_px1", "--data", str(ROOT.parent / "data"), "--variant", "SSL4EO",
            "--seed", str(args.seed), "--out", str(out), "--epochs", "60",
            "--clean-list", str(ROOT.parent / "audit/clean_chips.txt"), "--batch", "4", "--lr", "0.0001"]
train_px1.main()
