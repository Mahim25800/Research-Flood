"""Freeze candidates using only identifiers, and analyze paired per-chip score arrays."""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.stats import binomtest
from sklearn.metrics import average_precision_score

HERE = Path(__file__).resolve().parent
ARMS = ("adabn_st_valid", "adabn_physa_valid")


def roster():
    selected = {}
    for event, entry in json.loads((HERE / "cohort.json").read_text()).items():
        chips = sorted({chip for split, chip in entry["chips"]})
        if len(chips) >= 8:
            idx = np.linspace(0, len(chips)-1, min(48, len(chips)), dtype=int)
            selected[event] = [chips[i] for i in idx]
    return selected


def evaluate(root):
    events = {}
    for event, chips in roster().items():
        rows = []
        for seed in range(3):
            labels = []
            probabilities = {arm: [] for arm in ARMS}
            for chip in chips:
                # Label is independently aligned once per chip, shared by all arms and seeds.
                label = np.load(root / "labels" / (chip + ".npy"), allow_pickle=False)
                if not np.isin(label, [0, 1, 2, 255]).all():
                    raise ValueError(f"Unexpected label in {chip}")
                mask = (label == 0) | (label == 2)
                labels.append(label[mask] == 2)
                for arm in ARMS:
                    prob = np.load(root / event / str(seed) / arm / (chip + ".npy"), allow_pickle=False)
                    if prob.shape != label.shape or not np.isfinite(prob).all() or prob.min()<0 or prob.max()>1:
                        raise ValueError(f"Invalid probabilities for {chip}")
                    probabilities[arm].append(prob[mask])
            y = np.concatenate(labels)
            if not y.any():
                break
            rows.append({a: float(average_precision_score(y, np.concatenate(probabilities[a]))) for a in ARMS})
        events[event] = dict(seeds=rows, delta=float(np.mean([r[ARMS[1]]-r[ARMS[0]] for r in rows])) if rows else None)
    d = np.array([r["delta"] for r in events.values() if r["delta"] is not None])
    wins, losses = int(sum(d>0)), int(sum(d<0))
    return dict(events=events, mean_delta=float(d.mean()) if d.size else None, wins=wins,
                losses=losses, ties=int(sum(d==0)), sign_p=binomtest(wins,wins+losses,.5,alternative="greater").pvalue if wins+losses else None)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = evaluate(args.predictions) if args.predictions else roster()
    with args.out.open("x") as f:
        json.dump(result, f, indent=2)
