"""Select a single source-only threshold for both arms, averaging source events and seeds."""
from collections import defaultdict
import json
from pathlib import Path
import numpy as np
import torch

from experiment import FloodResNet, ROOT
from sen1floods11_unet_baseline import channel_stats, event_of, load_label, load_s1, read_split

HERE=Path(__file__).resolve().parent


def calibrate():
    data=ROOT.parent/"data"
    mean,std=channel_stats(data,read_split(data,"train"))
    valid=read_split(data,"valid")
    per_event=defaultdict(lambda: np.zeros(1000,dtype=np.int64))
    for seed in range(3):
        model=FloodResNet().cuda().eval()
        path=HERE/"source_models"/f"SSL4EO_seed{seed}"/"model.pt"
        model.load_state_dict(torch.load(path,weights_only=True,map_location="cpu"))
        with torch.inference_mode():
            for image,label in valid:
                raw=load_s1(data/"S1Hand"/image)
                x=(raw-mean[:,None,None])/std[:,None,None]
                p=model(torch.from_numpy(x)[None].cuda()).softmax(1)[0,1].cpu().numpy()
                y=load_label(data/"LabelHand"/label)
                bins=np.minimum((p[y==1]*1000).astype(int),999)
                per_event[event_of(image)]+=np.bincount(bins,minlength=1000)
    misses=np.mean([np.r_[0,h.cumsum()[:-1]]/h.sum() for h in per_event.values() if h.sum()],axis=0)
    idx=int(np.flatnonzero(misses<=.20)[-1])
    return dict(mean=mean.tolist(),std=std.tolist(),threshold=idx/1000,
                source_validation_mean_miss=float(misses[idx]),events=sorted(per_event))

if __name__=="__main__":
    with (HERE/"source_calibration.json").open("x") as f:
        json.dump(calibrate(),f,indent=2)
