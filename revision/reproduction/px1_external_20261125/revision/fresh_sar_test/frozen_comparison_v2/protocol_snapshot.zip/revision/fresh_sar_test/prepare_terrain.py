"""Prepare independent terrain evidence without opening any target label."""
from pathlib import Path
import sys
import numpy as np
import rasterio

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "src"))
import hand_fetch

def prepare(path):
    out = HERE/"terrain"/(path.name.removesuffix("_DEM.tif")+".npz")
    if out.exists():
        return
    with rasterio.open(path) as ds:
        if not ds.crs.is_projected or ds.crs.linear_units != "metre" or ds.transform.b or ds.transform.d:
            raise ValueError(f"Unsupported DEM grid {path}")
        dem = ds.read(1,masked=True).astype("f").filled(np.nan)
        hand = hand_fetch.hand_on_grid(ds.transform, ds.crs, ds.shape, preserve_nodata=True)
        gy,gx = np.gradient(dem, abs(ds.transform.e),abs(ds.transform.a))
    slope=np.degrees(np.arctan(np.hypot(gx,gy)))
    valid=np.isfinite(dem)&np.isfinite(slope)&np.isfinite(hand)&(hand>=0)&(hand<1e6)
    relative=dem-np.nanpercentile(dem,2) if np.isfinite(dem).any() else np.zeros_like(dem)
    t=np.stack([np.clip(relative/50,0,2),np.clip(slope/10,0,3),np.clip(hand/50,0,2)])
    with out.with_suffix(".tmp").open("wb") as f:
        np.savez_compressed(f,terrain=np.nan_to_num(t).astype("f"),valid=valid)
    out.with_suffix(".tmp").replace(out)

if __name__=="__main__":
    from concurrent.futures import ThreadPoolExecutor
    (HERE/"terrain").mkdir(exist_ok=True)
    hand_fetch.TILE_DIR=str(HERE/"hand_sources")
    # The public S3 product is published under one directory per tile.
    if not hand_fetch.probe():
        raise RuntimeError("HAND source unavailable")
    paths=sorted((HERE/"impactmesh_inputs").glob("*/DEM/*_DEM.tif"))
    with ThreadPoolExecutor(4) as pool:
        list(pool.map(prepare,paths))
    print("Prepared terrain",len(paths))
