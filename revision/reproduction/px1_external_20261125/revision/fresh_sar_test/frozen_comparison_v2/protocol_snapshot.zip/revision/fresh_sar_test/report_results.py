"""Report matched operational outcomes from saved contingency counts."""
import json
from pathlib import Path
import numpy as np
from experiment import ARMS

def summarize(path):
    result=json.loads(path.read_text())
    means={a:{} for a in ARMS}
    for arm in ARMS:
        by_metric={key:[] for key in ("IoU","miss","FPR","FDP")}
        for event in result["counts"].values():
            per={key:[] for key in by_metric}
            for row in event[arm]:
                tp,fp,fn,tn=(row[k] for k in ("tp","fp","fn","tn"))
                for key,n,d in (("IoU",tp,tp+fp+fn),("miss",fn,tp+fn),("FPR",fp,fp+tn),("FDP",fp,tp+fp)):
                    if d:
                        per[key].append(n/d)
            for key,values in per.items():
                if len(values)==3:
                    by_metric[key].append(float(np.mean(values)))
        means[arm]={key:{"mean":float(np.mean(v)) if v else None,"n_events":len(v)} for key,v in by_metric.items()}
        aps=[np.mean([r[arm] for r in e["seeds"]]) for e in result["primary"]["events"].values() if e["seeds"]]
        means[arm]["AP"]={"mean":float(np.mean(aps)) if aps else None,"n_events":len(aps)}
    return means
if __name__=="__main__":
    path=Path(__file__).resolve().parent/"frozen_comparison_v2/results.json"
    print(json.dumps(summarize(path),indent=2))
