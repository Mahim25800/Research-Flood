"""Freeze the local experiment before inference, run matched arms, and save auditable scores."""
import argparse
import hashlib
import json
import os
import platform
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from experiment import paired_predictions, ARMS, ROOT
from paired_test import evaluate, roster
from verify_inputs import sha

HERE=Path(__file__).resolve().parent
DEST=HERE/"frozen_comparison_v2"


def immutable_files():
    files=list(HERE.glob("*.py"))+[HERE/n for n in ("PROTOCOL.md","selected.json","cohort.json",
          "encoder.pth","input_verification.json","source_calibration.json","EXECUTION.md")]
    files.extend(ROOT/"src"/n for n in ("tta_px1.py","sen1floods11_unet_baseline.py","conformal_px1.py","train_px1.py","hand_fetch.py"))
    files.extend(HERE/"source_models"/f"SSL4EO_seed{s}"/n for s in range(3) for n in ("model.pt","results.json"))
    return {os.path.relpath(p,HERE):sha(p) for p in sorted(files)}


def freeze():
    verification=json.loads((HERE/"input_verification.json").read_text())
    chips=[c for group in roster().values() for c in group]
    assert set(verification)==set(chips) and len(chips)==516
    if DEST.exists():
        raise FileExistsError(DEST)
    files=immutable_files()
    DEST.mkdir()
    frozen=dict(created_utc=datetime.now(timezone.utc).isoformat(),files=files,
                python=platform.python_version(),torch=torch.__version__,numpy=np.__version__,
                cuda=torch.version.cuda,device=torch.cuda.get_device_name())
    (DEST/"freeze.json").write_text(json.dumps(frozen,indent=2))
    archive=DEST/"protocol_snapshot.zip"
    with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
        z.write(DEST/"freeze.json","freeze.json")
        for name in files:
            # Store code and manifests under their actual repository-relative names.
            # Model tensors are hash-pinned by freeze.json and retained at the recorded locations.
            if not name.endswith((".pth",".pt")):
                path=(HERE/name).resolve()
                z.write(path,str(path.relative_to(ROOT)))
    (DEST/"snapshot.sha256").write_text(sha(archive)+"  protocol_snapshot.zip\n")


def run():
    frozen=json.loads((DEST/"freeze.json").read_text())
    if immutable_files()!=frozen["files"]:
        raise ValueError("Frozen material changed")
    ref=json.loads((HERE/"source_calibration.json").read_text())
    verified=json.loads((HERE/"input_verification.json").read_text())
    labels=DEST/"labels"
    labels.mkdir(exist_ok=True)
    for event,chips in roster().items():
        ev={k:[] for k in ("raw","terr","physics_terrain","radar_valid","terrain_valid")}
        for chip in chips:
            path=HERE/"prepared"/(chip+".npz")
            lp=HERE/"prepared_labels"/(chip+".npy")
            if sha(path)!=verified[chip]["input_sha256"] or sha(lp)!=verified[chip]["label_sha256"]:
                raise ValueError(f"Input changed {chip}")
            target=labels/lp.name
            if not target.exists():
                shutil.copyfile(lp,target)
            if sha(target)!=verified[chip]["label_sha256"]:
                raise ValueError("Scoring label changed")
            with np.load(path) as d:
                for key,field in (("raw","raw"),("terr","terr"),("physics_terrain","terr"),
                                  ("radar_valid","rv"),("terrain_valid","hv")):
                    ev[key].append(d[field])
        ev["hand_ok"]=sum(m.any() for m in ev["terrain_valid"])
        for seed in range(3):
            worker=DEST/event/str(seed)
            done=worker/"scores.json"
            if done.exists():
                manifest=json.loads(done.read_text())
                if all(sha(worker/n)==v for n,v in manifest.items()) and len(manifest)==len(chips)*2:
                    continue
                raise ValueError("Previous score checkpoint failed verification")
            diagnostics={}
            outputs=paired_predictions(ev,ref["mean"],ref["std"],HERE/"source_models"/f"SSL4EO_seed{seed}"/"model.pt",seed,diagnostics=diagnostics)
            manifest={}
            for arm,scores in outputs.items():
                assert len(scores)==len(chips)
                folder=worker/arm
                folder.mkdir(parents=True,exist_ok=True)
                for chip,p in zip(chips,scores):
                    assert p.dtype==np.float32 and np.isfinite(p).all()
                    dst=folder/(chip+".npy")
                    np.save(dst,p)
                    manifest[str(dst.relative_to(worker))]=sha(dst)
            (worker/"diagnostics.json").write_text(json.dumps(diagnostics,indent=2))
            done.write_text(json.dumps(manifest,indent=2))
            print(event,seed,"verified",flush=True)
    primary=evaluate(DEST)
    threshold=ref["threshold"]
    secondary={}
    for event,chips in roster().items():
        secondary[event]={}
        for arm in ARMS:
            rows=[]
            for seed in range(3):
                tp=fp=fn=tn=0
                for chip in chips:
                    lab=np.load(labels/(chip+".npy"))
                    pred=np.load(DEST/event/str(seed)/arm/(chip+".npy"))>=threshold
                    tp+=int((pred&(lab==2)).sum())
                    fp+=int((pred&(lab==0)).sum())
                    fn+=int((~pred&(lab==2)).sum())
                    tn+=int((~pred&(lab==0)).sum())
                rows.append(dict(tp=tp,fp=fp,fn=fn,tn=tn))
            secondary[event][arm]=rows
    (DEST/"results.json").write_text(json.dumps(dict(primary=primary,threshold=threshold,counts=secondary),indent=2))

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=["freeze","run"])
    if parser.parse_args().action=="freeze":
        freeze()
    else:
        run()
