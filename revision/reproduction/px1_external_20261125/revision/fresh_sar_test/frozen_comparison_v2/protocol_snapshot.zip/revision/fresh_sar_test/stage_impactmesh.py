"""Stream only the pinned ImpactMesh archives. Retain selected members and verify archive digests."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import tarfile

import requests

HERE = Path(__file__).resolve().parent
REV = "4432601ff08e6fb256f4ac3a59d9d30c1f069774"
REPO = "ibm-esa-geospatial/ImpactMesh-Flood"
selected = {c for chips in json.loads((HERE/"selected.json").read_text()).values() for c in chips}

class HashReader:
    def __init__(self, response):
        self.raw = response.raw
        self.sha = hashlib.sha256()
    def read(self, n):
        b = self.raw.read(n)
        self.sha.update(b)
        return b

class RangeReader:
    """Use independently retriable HTTP ranges; give tarfile a sequential stream."""
    def __init__(self,url,size):
        self.url=url
        self.size=size
        self.pos=0
        self.buffer=b""
        self.sha=hashlib.sha256()

    def read(self,n):
        if not self.buffer and self.pos < self.size:
            start=self.pos
            end=min(start+16*1024**2,self.size)-1
            for attempt in range(6):
                try:
                    r=requests.get(self.url+f"?offset={start}&attempt={attempt}",
                                   headers={"Range":f"bytes={start}-{end}"},timeout=(30,75))
                    r.raise_for_status()
                    if r.headers.get("Content-Range")!=f"bytes {start}-{end}/{self.size}" or len(r.content)!=end-start+1:
                        raise IOError("Invalid Content-Range")
                    self.buffer=r.content
                    self.pos=end+1
                    self.sha.update(self.buffer)
                    break
                except (requests.RequestException, IOError):
                    if attempt==5:
                        raise
        chunk=self.buffer[:n]
        self.buffer=self.buffer[n:]
        return chunk

def stage(item):
    archive, expected, size = item
    split, filename = archive.split("/")
    folder = HERE/"impactmesh_inputs"/split/filename[:-4]
    folder.mkdir(parents=True,exist_ok=True)
    marker = folder/"verified.json"
    if marker.exists() and json.loads(marker.read_text())["archive_sha256"]==expected:
        return
    wanted = selected.intersection((HERE/(split+".txt")).read_text().splitlines())
    found = {}
    url = f"https://huggingface.co/datasets/{REPO}/resolve/{REV}/{archive}"
    stream=RangeReader(url,size)
    with tarfile.open(fileobj=stream,mode="r|",bufsize=2**20) as tar:
        for member in tar:
            name=Path(member.name).name
            suffix = "_annotation_flood.tif" if filename == "MASK.tar" else "_"+filename[:-4]
            chip = name.split(suffix)[0]
            if chip in wanted and member.isfile():
                data=tar.extractfile(member).read()
                if chip in found:
                    raise ValueError("Duplicate chip "+chip)
                (folder/name).write_bytes(data)
                found[chip]=hashlib.sha256(data).hexdigest()
    while stream.read(2**20):
        pass
    if stream.sha.hexdigest()!=expected or set(found)!=wanted:
        raise ValueError(f"{archive} hash {stream.sha.hexdigest()} matched {len(found)}/{len(wanted)}")
    marker.write_text(json.dumps(dict(archive_sha256=expected,chips=found),indent=2))
    print("Verified",archive,len(found),flush=True)

if __name__=="__main__":
    jobs=[]
    for split in ("test","val","train"):
        r=requests.get(f"https://huggingface.co/api/datasets/{REPO}/tree/{REV}/{split}",timeout=30)
        r.raise_for_status()
        jobs.extend((x["path"],x["lfs"]["oid"],x["size"]) for x in r.json() if Path(x["path"]).stem in {"S1RTC","DEM","MASK"})
    with concurrent.futures.ThreadPoolExecutor(3) as pool:
        list(pool.map(stage,jobs))
