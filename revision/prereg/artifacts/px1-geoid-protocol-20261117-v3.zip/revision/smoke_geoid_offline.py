"""Exercise the real adapters and statistical path without external dataset access."""
import argparse
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

import geoid_evaluate as evaluator
import tta_px1

parser = argparse.ArgumentParser()
parser.add_argument('checkpoints', type=Path)
args = parser.parse_args()
root = Path(__file__).parent
source = json.loads((root / 'geoid_source_reference.json').read_text())
checkpoints = json.loads((root / 'geoid_checkpoint_sha256.json').read_text())
torch.set_num_threads(1)
tta_px1.ADABN_BATCHES = 1
for name, expected in checkpoints.items():
    assert evaluator.digest(args.checkpoints / name) == expected

raw = np.random.default_rng(12).normal(-24, 4, (2, 32, 32)).astype('float32')
valid = np.ones((32, 32), dtype=bool)
valid[:2] = False
lab = np.zeros(valid.shape, dtype='uint8')
lab[4:12, 4:12] = 1
lab[12:24, 12:24] = 2
lab[~valid] = 255
anchor = valid & (raw[0] < -24)
event = dict(raw=[raw], radar_valid=[valid], terrain_valid=[valid],
             physics_terrain=[np.zeros((3,32,32), dtype='float32')],
             lab=[np.full(valid.shape, 255, dtype='uint8')], clean=[False])
methods = {}
for seed, name in enumerate(checkpoints):
    for method in evaluator.METHODS:
        scores = []
        options = SimpleNamespace(seed=0, model_seed=seed, steps=1,
                                  score_observer=lambda _, p: scores.append(p))
        evaluator.run_one(method, 'V0', 'synthetic', event,
                          np.asarray(source['mean'], dtype='float32'),
                          np.asarray(source['std'], dtype='float32'), options, 'cpu',
                          ckpt=args.checkpoints/name)
        methods[f'{seed}:{method}'] = evaluator.score(np.stack(scores), lab[None], anchor[None])

result = evaluator.analyse({'synthetic': {'methods': methods}}, source['threshold_bins'])
assert len(result['paired_ap']) == 1
assert sum(result[k] for k in ('wins', 'losses', 'ties')) == 1
assert methods['0:none_valid']['flood']['fixed_0.5']['tp'] + methods['0:none_valid']['flood']['fixed_0.5']['fn'] == 144
print('All three checkpoint hashes and 15 synthetic method/seed combinations verified')
