# GEOID-Flood evaluation snapshot

Use GEOID-Flood v1.1 at revision `4f1b9c52da789dbad9333e8f62c7b27ff48304bd`, tree `geoid-flood-heldout`, activations EMSR857–EMSR871. The snapshot has no network download entry point. Prepare the pinned release inventory and aligned support files after the protocol is recorded and held-out access is authorized.

The external evaluator consumes a JSON object containing `release`, `overlaps`, and `tiles`. The `overlaps` object maps each confirmed duplicate activation to its documented reason. Record the comparison with Sen1Floods11, Kuro Siwo, and MMFlood alongside the inventory. Every tile has a unique `id`, an `activation` such as EMSR857, and relative raster paths in `s1_post`, `dem`, `label`, and `hand`. Use the published 1,301-tile inventory. The paths must refer to its corresponding post-event S1 GRD, label and elevation rasters and co-registered GLO-30 HAND v1/2021 in metres. Use only the post-event radar asset per tile. For unavailable HAND use null and document the coverage, so the physical rule cannot fire there. The bundled `src/hand_fetch.py` supplies the GLO-30 alignment routine with `preserve_nodata=True`. Inventory assembly and HAND alignment on real GEOID-Flood are pending.

The code checks the named VV/VH bands and raster grids. Radar validity uses raster masks, finite positive linear power in both channels, and the existing -49.9 dB sentinel cutoff. Selection is independent of labels. The evaluator sorts the tile IDs lexicographically, uses row-major quadrants, and takes evenly spaced eligible indices, rounding down. Label value 255 is ignored during scoring. The physical rule uses DEM slope and aligned HAND, and excludes unavailable terrain. Permanent water is ignored for flood-only scoring and counted as water for all-water scoring.

Primary AP uses the float32 water scores with ties grouped. The one-sided exact sign test uses the average of the paired seed differences within each activation. The five compared arms use the same invalid-radar treatment and inputs. Ordinary self-training uses the same AdaBN and teacher update settings as physical self-training with the physical label additions and conflict handling disabled. The source-only operating point is a shared threshold of 0.208 derived from archived unadapted Sen1Floods11 leave-one-event-out all-water predictions. The released reference JSON stores the eleven calibration histograms and hashes. The shared reference is distinct from method-specific leave-one-activation-out calibration on the external data. Neither threshold enters the primary AP test.

The checkpoint directory contains `V0_seed0/model.pt`, `V0_seed1/model.pt`, and `V0_seed2/model.pt`. Supply the existing model files separately. The evaluator verifies SHA-256 before loading them. The snapshot contains no model weights or held-out files.

Tested with Python 3.12, PyTorch 2.6.0+cu124, NumPy 2.5.4, Rasterio 1.5.2, SciPy 1.17.1 and scikit-learn 1.5.1. Use matching versions for the recorded environment. Run the following offline checks and evaluation from the extracted archive root:

```text
python revision/smoke_geoid_offline.py PATH_TO_RUNS
python revision/geoid_evaluate.py --root PREPARED_RASTERS --inventory PINNED_INVENTORY.json --checkpoints PATH_TO_RUNS --out NEW_RESULTS_DIR --device cuda
```

The synthetic smoke exercised all five real methods with all three frozen checkpoints on CPU using shortened adaptation, followed by scoring and the primary test. The offline runner has yet to process the actual release rasters, real HAND, or full GPU workload. Save the prepared inventory, overlap decisions, input checksums, HAND coverage, and exact runtime versions alongside the output.
