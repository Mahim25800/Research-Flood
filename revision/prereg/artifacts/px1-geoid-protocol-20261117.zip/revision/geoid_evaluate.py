"""Offline GEOID-Flood evaluation from a release inventory and aligned rasters."""
import argparse
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import rasterio
from scipy.stats import binomtest
from sklearn.metrics import average_precision_score

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from conformal_px1 import BINS
from rev_analyse import curves, k_crc
from tta_px1 import run_one, valid_adaptive_dark, HAND_LOW, SLOPE_LOW, STEPS

RELEASE = '4f1b9c52da789dbad9333e8f62c7b27ff48304bd'
METHODS = ('none_valid', 'adabn_valid', 'adabn_st_valid',
           'adabn_physa_valid_post', 'adabn_physa_valid')
ACTIVATIONS = {f'EMSR{i}' for i in range(857, 872)}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def raster(root, name, grid=None, bands=None):
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError(f'Input path leaves raster root: {name}')
    with rasterio.open(path) as src:
        current = (src.crs, src.transform, src.height, src.width)
        if grid is not None and grid != current:
            raise ValueError(f'Unaligned raster: {name}')
        if bands and tuple(src.descriptions) != bands:
            raise ValueError(f'Unexpected bands: {name}')
        return src.read(masked=True), current


def chips(root, tile):
    radar, grid = raster(root, tile['s1_post'], bands=('VV', 'VH'))
    crs, affine, height, width = grid
    if (height, width) != (1024, 1024) or not crs or not crs.is_projected or (
            affine.a, affine.e, affine.b, affine.d) != (10, -10, 0, 0):
        raise ValueError('Expected a north-up 1024 × 1024 raster at 10 m')
    linear = radar.astype('float32').filled(np.nan)
    valid = (np.isfinite(linear) & (linear > 0)).all(0)
    with np.errstate(divide='ignore', invalid='ignore'):
        raw = np.clip(10 * np.log10(linear), -50, 5)
    valid &= (raw > -49.9).all(0)
    return raw, valid, grid


def evaluate_event(root, tiles, normalization, checkpoints, device):
    # Select from input support before reading labels. Order by tile ID, then row/column.
    candidates = []
    for tile in sorted(tiles, key=lambda row: row['id']):
        _, valid, _ = chips(root, tile)
        for y in (0, 512):
            for x in (0, 512):
                if valid[y:y+512, x:x+512].sum() >= 512*512//2:
                    candidates.append((tile, y, x))
    if len(candidates) < 8:
        return {'eligible_chips': len(candidates), 'excluded': 'fewer than eight eligible chips'}
    indices = np.linspace(0, len(candidates)-1, min(48, len(candidates)), dtype=int)
    event = defaultdict(list)
    labels, selected = [], []
    for index in indices:
        tile, y, x = candidates[index]
        raw, valid, grid = chips(root, tile)
        dem, _ = raster(root, tile['dem'], grid)
        dem = dem[0].astype('float32').filled(np.nan)
        hand = np.full(dem.shape, np.nan, dtype='float32')
        if tile.get('hand'):
            values, _ = raster(root, tile['hand'], grid)
            hand = values[0].astype('float32').filled(np.nan)
        north, east = np.gradient(dem, 10)
        slope = np.degrees(np.arctan(np.hypot(north, east)))
        terrain_valid = np.isfinite(dem) & np.isfinite(slope) & np.isfinite(hand) & (hand >= 0)
        terrain = np.stack([np.zeros_like(dem), np.nan_to_num(slope, nan=90)/10,
                            np.where(terrain_valid, np.clip(hand, 0, 100), 100)/50])
        truth, _ = raster(root, tile['label'], grid)
        truth = truth[0].filled(255)
        if not np.isin(truth, [0, 1, 2, 255]).all():
            raise ValueError('Unexpected GEOID-Flood label value')
        window = np.s_[y:y+512, x:x+512]
        event['raw'].append(raw[:, window[0], window[1]].copy())
        event['radar_valid'].append(valid[window].copy())
        event['terrain_valid'].append(terrain_valid[window].copy())
        event['physics_terrain'].append(terrain[:, window[0], window[1]].astype('float32'))
        labels.append(np.where(valid[window], truth[window], 255).astype('uint8'))
        selected.append([tile['id'], y, x])
    # The model observer receives scores only. True labels are external to adaptation.
    event['lab'] = [np.full(y.shape, 255, dtype='uint8') for y in labels]
    event['clean'] = [False] * len(labels)
    label = np.stack(labels)
    tv, th = valid_adaptive_dark(event['raw'], event['radar_valid'])
    anchor = np.stack([
        rv & hv & (raw[0] < tv) & (raw[1] < th) & (terrain[2]*50 < HAND_LOW)
        & (terrain[1]*10 < SLOPE_LOW)
        for rv, hv, raw, terrain in zip(event['radar_valid'], event['terrain_valid'],
                                       event['raw'], event['physics_terrain'])
    ])
    methods = {}
    for seed, checkpoint in enumerate(checkpoints):
        for method in METHODS:
            scores = []
            args = SimpleNamespace(seed=0, model_seed=seed, steps=STEPS,
                                   score_observer=lambda _, p: scores.append(p))
            run_one(method, 'V0', 'geoid', event,
                    np.asarray(normalization['mean'], dtype='float32'),
                    np.asarray(normalization['std'], dtype='float32'), args, device,
                    ckpt=checkpoint)
            methods[f'{seed}:{method}'] = score(np.stack(scores), label, anchor)
    return {'eligible_chips': len(candidates), 'selected': selected, 'methods': methods}


def score(probability, label, anchor):
    if not np.isfinite(probability).all() or (probability < 0).any() or (probability > 1).any():
        raise ValueError('Invalid model scores')
    result = {}
    for name, support, positive in (
        ('flood', (label == 0) | (label == 2), label == 2),
        ('flood_outside', ((label == 0) | (label == 2)) & ~anchor, label == 2),
        ('all_water', label != 255, (label == 1) | (label == 2)),
    ):
        truth = positive[support]
        scores = probability[support]
        ap = float(average_precision_score(truth, scores)) if truth.any() else None
        bins = np.minimum((scores * BINS).astype(int), BINS-1)
        hist = [np.bincount(bins[truth == cls], minlength=BINS).tolist() for cls in (0, 1)]
        result[name] = {'ap': ap, 'histogram': hist}
    return result


def operating_point(hist, threshold):
    neg, pos = np.asarray(hist)
    tp, fp = int(pos[threshold:].sum()), int(neg[threshold:].sum())
    fn, tn = int(pos.sum()) - tp, int(neg.sum()) - fp
    return {
        'iou': tp/(tp+fp+fn) if tp+fp+fn else None,
        'miss': fn/(tp+fn) if tp+fn else None,
        'fpr': fp/(fp+tn) if fp+tn else None,
        'precision': tp/(tp+fp) if tp+fp else None,
        'tp': tp, 'fp': fp, 'tn': tn, 'fn': fn,
    }


def analyse(events, source):
    paired, undefined = {}, []
    for activation, result in events.items():
        methods = result.get('methods')
        if methods is None:
            continue
        pairs = [(methods[f'{seed}:adabn_physa_valid']['flood']['ap'],
                  methods[f'{seed}:adabn_physa_valid_post']['flood']['ap']) for seed in range(3)]
        if any(a is None or b is None for a, b in pairs):
            undefined.append(activation)
        else:
            paired[activation] = float(np.mean([a-b for a,b in pairs]))
    values = list(paired.values())
    wins = sum(x > 0 for x in values)
    losses = sum(x < 0 for x in values)
    primary = dict(paired_ap=paired, wins=wins, losses=losses, ties=len(values)-wins-losses,
                   undefined=undefined, mean=float(np.mean(values)) if values else None,
                   median=float(np.median(values)) if values else None,
                   p_value=binomtest(wins, wins+losses, alternative='greater').pvalue if wins+losses else None)
    scored = {e: v['methods'] for e,v in events.items() if 'methods' in v}
    for e, arms in scored.items():
        for arm, supports in arms.items():
            for support, s in supports.items():
                h = s['histogram']
                s['fixed_0.5'] = operating_point(h, BINS//2)
                s['source_only'] = operating_point(h, source[arm.split(':',1)[1]])
                pool = [curves(np.asarray(a[arm][support]['histogram']))[0]
                        for other,a in scored.items() if other != e
                        and sum(a[arm][support]['histogram'][1]) > 0]
                k = k_crc(pool, 0.2) if pool else None
                s['loao_0.2'] = None if k is None else dict(threshold_bin=k, **operating_point(h,k))
    return primary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--inventory', type=Path, required=True)
    parser.add_argument('--checkpoints', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--device', choices=['cpu','cuda'], default='cuda')
    args = parser.parse_args()
    manifest = json.loads(Path(__file__).with_name('geoid_checkpoint_sha256.json').read_text())
    paths = [args.checkpoints / name for name in manifest]
    for path, expected in zip(paths, manifest.values()):
        if digest(path) != expected:
            raise ValueError(f'Checkpoint hash mismatch: {path.name}')
    inv = json.loads(args.inventory.read_text())
    source_path = Path(__file__).with_name('geoid_source_reference.json')
    source = json.loads(source_path.read_text())
    if inv['release'] != RELEASE or len(inv['tiles']) != 1301:
        raise ValueError('Expected the complete pinned v1.1 held-out inventory')
    unique = {r['id'] for r in inv['tiles']}
    if len(unique) != 1301 or {r['activation'] for r in inv['tiles']} != ACTIVATIONS:
        raise ValueError('Duplicate tile IDs or activation coverage mismatch')
    excluded = inv['overlaps']
    if not set(excluded) <= ACTIVATIONS or not all(excluded.values()):
        raise ValueError('Invalid overlap decisions')
    if set(source['threshold_bins']) != set(METHODS) or not all(
            type(v) is int and 0 <= v <= BINS for v in source['threshold_bins'].values()):
        raise ValueError('Source calibration must specify each method before evaluation')
    by_activation = defaultdict(list)
    for tile in inv['tiles']:
        by_activation[tile['activation']].append(tile)
    args.out.mkdir(parents=True, exist_ok=False)
    events = {}
    for activation, tiles in sorted(by_activation.items()):
        result = {'excluded': excluded[activation]} if activation in excluded else evaluate_event(
            args.root, tiles, source, paths, args.device)
        (args.out / f'{activation}.json').write_text(json.dumps(result, allow_nan=False))
        events[activation] = result
    result = dict(release=RELEASE, inventory_sha256=digest(args.inventory),
                  source_sha256=digest(source_path), checkpoints=manifest,
                  primary=analyse(events, source['threshold_bins']), events=events)
    (args.out / 'results.json').write_text(json.dumps(result, allow_nan=False))


if __name__ == '__main__':
    main()
