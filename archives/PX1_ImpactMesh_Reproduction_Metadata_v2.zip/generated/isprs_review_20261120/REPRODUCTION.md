# ImpactMesh reproduction metadata

The archive provides the frozen protocol snapshot, original run verification and scores manifests, report, and code used to verify or regenerate the analysis. It also includes the post-hoc CPU control reports. Local files use the paths relative to the research repository's revision directory. The SHA256SUMS file identifies the bundled members.

The metadata archive excludes radar and label arrays, source weights and prediction tensors. The original verifier requires those files at the recorded paths. The snapshot identifies the public dataset revision and pins the expected input and checkpoint hashes. Training, preparation and run details are in the nested protocol snapshot. Reproducing the post-hoc CPU arms requires the original checkpoints, prepared chips and labels.

Review the input and model redistribution terms and approve the archive before a public deposit. This local archive provides a manifest and numerical results, with artifact-level reproduction depending on access to the pinned inputs.
