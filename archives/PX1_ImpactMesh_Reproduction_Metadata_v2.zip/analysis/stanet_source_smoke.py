"""Audit paired Sen1Floods11 rasters, then smoke-test STANet seed 0 on Kaggle GPU."""

import csv
import hashlib
import json
from pathlib import Path
import random
import sys
import time
from urllib.request import Request, urlopen
from zipfile import ZipFile

import numpy as np
import rasterio
from rasterio.enums import Resampling
from rasterio.io import MemoryFile
from rasterio.warp import reproject
import torch
from torch import nn
from torch.nn import functional as F


ROOT = Path("/kaggle/working")
SOURCE = Path("/tmp/px1_stanet_source_smoke")
REV = "6152d72f55df00a43d341580970be7a58c6b0cd5"
ARCHIVES = {
    "pre": ("PRE_S1-20230517T191707Z-001.zip", "4a32637c56ea519bd3c4baca208b289d", "_S1_PREHand.tif"),
    "post": ("POST_S1-20230517T191716Z-001.zip", "40a505cfbd5318d94a9d5bd7aef88561", "_S1Hand.tif"),
    "label": ("Labels-20230517T191741Z-001.zip", "069b4c05eefb7a6e72c1adb34aaf1a24", "_LabelHand.tif"),
}


def digest(path, algorithm="sha256"):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, algorithm).hexdigest()


def download(url, path, md5=None):
    for attempt in range(3):
        try:
            with urlopen(Request(url, headers={"User-Agent": "PX1-source-research"}), timeout=90) as response:
                with path.open("wb") as stream:
                    while block := response.read(1024 * 1024):
                        stream.write(block)
            if md5 is not None and digest(path, "md5") != md5:
                raise IOError(f"MD5 mismatch for {path.name}")
            return
        except OSError:
            if attempt == 2:
                raise
            time.sleep(2 ** (attempt + 1))


def grid(ds):
    if ds.crs is None or not ds.transform.is_rectilinear or ds.width < 256 or ds.height < 256:
        raise ValueError(f"Invalid raster grid: {ds.crs}, {ds.transform}, {ds.shape}")
    return ds.crs, ds.transform, ds.shape


def grid_offset(reference, other):
    """Maximum displacement in reference pixels, including accumulated scale error."""
    crs, transform, shape = reference
    other_crs, other_transform, other_shape = other
    if crs != other_crs or shape != other_shape:
        return None
    height, width = shape
    relative = ~transform * other_transform
    return max(max(abs(px - x), abs(py - y))
               for x, y in ((0, 0), (width, 0), (0, height), (width, height))
               for px, py in (relative * (x, y),))


def index(archive, suffix):
    members = {}
    for member in archive.namelist():
        name = Path(member).name
        if name.endswith(suffix):
            chip = name.removesuffix(suffix)
            if chip in members:
                raise ValueError(f"Duplicate archive chip: {chip}")
            members[chip] = member
    return members


def vv(ds):
    descriptions = [name.strip().lower() if name else "" for name in ds.descriptions]
    if descriptions.count("vv") == 1:
        band = descriptions.index("vv") + 1
    elif ds.count == 2 and not any(descriptions):
        band = 1  # Published VV/VH band order.
    else:
        raise ValueError(f"Unrecognized SAR band descriptions: {descriptions}")
    values = ds.read(band, masked=True).astype(np.float32).filled(np.nan)
    values[~np.isfinite(values)] = np.nan
    if not np.isfinite(values).any() or not -45 < np.nanmedian(values) < 0:
        raise ValueError("VV does not look like usable dB radar")
    return values


def read_triplet(archives, indices, chip):
    import contextlib

    with contextlib.ExitStack() as stack:
        rasters = {}
        for key, archive in archives.items():
            memory = stack.enter_context(MemoryFile(archive.read(indices[key][chip])))
            rasters[key] = stack.enter_context(memory.open())
        pre, post, lab = (rasters[key] for key in ("pre", "post", "label"))
        pre_grid, post_grid, label_grid = (grid(ds) for ds in (pre, post, lab))
        label_offset = grid_offset(post_grid, label_grid)
        if lab.count != 1 or label_offset is None or label_offset > 1e-4:
            raise ValueError(f"Label and post-event grids differ: {label_offset} pixels")
        # Some GeoTIFFs declare 0 as nodata even though the publisher defines it as dry.
        reference = lab.read(1)
        classes = np.unique(reference).tolist()
        if not set(classes) <= {-1, 0, 1, 255}:
            raise ValueError(f"Unsupported label values {classes}")
        early, late = vv(pre), vv(post)
        pre_offset = grid_offset(post_grid, pre_grid)
        aligned = pre_offset is not None and pre_offset <= 1e-4
        if not aligned:
            destination = np.full(post.shape, np.nan, dtype=np.float32)
            reproject(early, destination, src_crs=pre.crs, src_transform=pre.transform,
                      dst_crs=post.crs, dst_transform=post.transform, src_nodata=np.nan,
                      dst_nodata=np.nan, resampling=Resampling.bilinear)
            early = destination
        both = np.isfinite(early) & np.isfinite(late)
        labeled = (reference == 0) | (reference == 1)
        valid = both & labeled
        if not valid.any():
            raise ValueError("No joint labeled radar support")
        stats = {"already_aligned": aligned, "classes": classes, "shape": list(post.shape),
                 "label_grid_offset_px": label_offset, "pre_grid_offset_px": pre_offset,
                 "label_nodata_tag": str(lab.nodata),
                 "labeled": int(labeled.sum()), "valid": int(valid.sum()),
                 "water": int((valid & (reference == 1)).sum())}
        return early, late, reference, valid, stats


def audit(work):
    from contextlib import ExitStack

    data = SOURCE
    data.mkdir()
    with ExitStack() as stack:
        archives, indices = {}, {}
        for key, (name, md5, suffix) in ARCHIVES.items():
            path = data / name
            print(f"Downloading {key}", flush=True)
            download(f"https://zenodo.org/records/7946594/files/{name}?download=1", path, md5)
            archives[key] = stack.enter_context(ZipFile(path))
            indices[key] = index(archives[key], suffix)
        paired = set.intersection(*(set(members) for members in indices.values()))
        if len(paired) != 418:
            raise ValueError(f"Unexpected number of archived triplets: {len(paired)}")

        result, samples = {}, {}
        for split, rows in SPLITS.items():
            accepted, rejected, missing, smoke_chips = {}, {}, [], []
            for row in csv.reader(rows.splitlines()):
                chip = row[0].removesuffix("_S1Hand.tif")
                if chip not in paired:
                    missing.append(chip)
                    continue
                try:
                    early, late, reference, valid, stats = read_triplet(archives, indices, chip)
                except (ValueError, rasterio.errors.RasterioError) as exc:
                    rejected[chip] = str(exc)
                    continue
                accepted[chip] = stats
                if len(smoke_chips) < 8 and 0 < stats["water"] < stats["valid"]:
                    for y in (0, early.shape[0] - 256):
                        for x in (0, early.shape[1] - 256):
                            window = np.s_[y:y + 256, x:x + 256]
                            support = valid[window]
                            water = (reference[window] == 1) & support
                            if support.mean() >= .75 and 0 < water.sum() < support.sum():
                                smoke_chips.append((chip, np.stack((early[window], late[window])),
                                                    water, support.copy()))
                                break
                        else:
                            continue
                        break
            result[split] = {"accepted": accepted, "rejected": rejected, "missing": missing,
                             "smoke_chips": [entry[0] for entry in smoke_chips]}
            samples[split] = smoke_chips
            print(f"{split}: {len(accepted)} usable, {len(rejected)} rejected, {len(missing)} missing", flush=True)
    (work / "raster_audit.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    if any(len(samples[split]) < 8 for split in ("train", "validation")):
        raise ValueError("Insufficient audited labeled crops for GPU smoke")
    return samples


def load_stanet():
    package = SOURCE / "stanet_upstream"
    if not package.exists():
        package.mkdir()
        (package / "__init__.py").touch()
        for name in ("backbone.py", "mynet3.py", "BAM.py", "PAM2.py"):
            download(f"https://raw.githubusercontent.com/justchenhao/STANet/{REV}/models/{name}", package / name)
        sys.path.insert(0, str(package.parent))
    from stanet_upstream.backbone import CDSA, define_F

    return define_F(in_c=1, f_c=64, type="mynet3"), CDSA(in_c=64, ds=4, mode="BAM")


def train_smoke(work, samples):
    encoder, attention = load_stanet()
    model = nn.ModuleList((encoder, attention)).cuda()
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)
    pixels = np.concatenate([np.clip(images[:, valid], -23, 0).ravel()
                             for _, images, _, valid in samples["train"]])
    mean, std = float(pixels.mean()), float(pixels.std())
    if not np.isfinite(std) or std <= 0:
        raise ValueError("Invalid training-only VV normalization")

    def loss_for(batch):
        _, images, targets, valid = zip(*batch)
        images = (np.clip(np.stack(images), -23, 0) - mean) / std
        images = torch.from_numpy(np.nan_to_num(images)).cuda()
        targets = torch.from_numpy(np.stack(targets)).cuda()
        valid = torch.from_numpy(np.stack(valid)).cuda()
        first, second = attention(encoder(images[:, :1]), encoder(images[:, 1:]))
        distance = torch.linalg.vector_norm(first - second, dim=1, keepdim=True)
        distance = F.interpolate(distance, size=targets.shape[-2:], mode="bilinear", align_corners=False)[:, 0]
        changed, unchanged = targets & valid, ~targets & valid
        return distance[unchanged].square().mean() + (2 - distance[changed]).clamp_min(0).square().mean()

    training = samples["train"]
    random.Random(0).shuffle(training)
    before = next(encoder.parameters()).detach().clone()
    losses = []
    for i in range(0, len(training), 2):
        optimizer.zero_grad(set_to_none=True)
        loss = loss_for(training[i:i + 2])
        if not torch.isfinite(loss):
            raise ValueError("Nonfinite STANet training loss")
        loss.backward()
        optimizer.step()
        losses.append(float(loss.detach()))
    if torch.equal(before, next(encoder.parameters()).detach()):
        raise ValueError("STANet encoder parameters did not update")
    model.eval()
    with torch.no_grad():
        val = [float(loss_for(samples["validation"][i:i + 2])) for i in range(0, 8, 2)]
    if not np.isfinite(val).all():
        raise ValueError("Nonfinite STANet source validation losses")

    model_path = work / "seed0_smoke.pt"
    torch.save({"model": model.state_dict(), "normalize": (mean, std), "seed": 0, "stanet_commit": REV}, model_path)
    result = {"status": "passed", "seed": 0, "gpu": torch.cuda.get_device_name(),
              "torch": torch.__version__, "stanet_commit": REV, "updates": len(losses),
              "train_loss": losses, "source_val_loss": val, "normalize": [mean, std],
              "checkpoint_sha256": digest(model_path), "audit_sha256": digest(work / "raster_audit.json"),
              "positive_label": "published visible water; permanent water is not separately labeled"}
    (work / "smoke_report.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result), flush=True)


def main():
    if not ROOT.is_dir() or not torch.cuda.is_available():
        raise RuntimeError("This smoke test requires Kaggle GPU")
    torch.manual_seed(0)
    torch.set_num_threads(2)
    work = ROOT / "stanet_source_smoke"
    work.mkdir()
    train_smoke(work, audit(work))
