"""Full paired VV source training, staged with the verified STANet v2 loader."""

from contextlib import ExitStack

from scipy.optimize import minimize
from scipy.special import expit


SEEDS = (0, 1, 2)
EPOCHS = 12
SIZE = 256
BATCH = 2


def source_tiles():
    SOURCE.mkdir()
    with ExitStack() as stack:
        archives, indices = {}, {}
        for key, (name, md5, suffix) in ARCHIVES.items():
            path = SOURCE / name
            download(f"https://zenodo.org/records/7946594/files/{name}?download=1", path, md5)
            archives[key] = stack.enter_context(ZipFile(path))
            indices[key] = index(archives[key], suffix)
        samples = {}
        for split, roster in ROSTER.items():
            samples[split] = []
            for chip, pin in roster.items():
                a, b, ref, valid, stats = read_triplet(archives, indices, chip)
                if stats != pin:
                    raise ValueError(f"Source raster audit changed: {chip}")
                for y in range(0, a.shape[0], SIZE):
                    for x in range(0, a.shape[1], SIZE):
                        region = np.s_[y:y + SIZE, x:x + SIZE]
                        support = valid[region]
                        if not support.any():
                            continue
                        pad = [(0, SIZE - d) for d in support.shape]
                        image = np.stack([np.pad(raw[region], pad, constant_values=np.nan) for raw in (a, b)])
                        samples[split].append((image, np.pad(ref[region] == 1, pad), np.pad(support, pad)))
            print(f"{split}: {len(roster)} verified chips, {len(samples[split])} tiles", flush=True)
    return samples


def train_normalization(tiles):
    count = total = squares = 0
    for radar, _, valid in tiles:
        vv = np.clip(radar[:, valid], -23, 0).astype(np.float64)
        count += vv.size
        total += vv.sum()
        squares += np.square(vv).sum()
    mean = total / count
    std = np.sqrt(squares / count - mean**2)
    if not np.isfinite(std) or std <= 0:
        raise ValueError("Invalid source training normalization")
    return float(mean), float(std)


def distances(model, batch, normalization):
    images, targets, valid = zip(*batch)
    mean, std = normalization
    images = (np.clip(np.stack(images), -23, 0) - mean) / std
    images = torch.from_numpy(np.nan_to_num(images)).cuda()
    labels = torch.from_numpy(np.stack(targets)).cuda()
    valid = torch.from_numpy(np.stack(valid)).cuda()
    encoder, attention, dropout = model
    early, late = attention(dropout(encoder(images[:, :1])), dropout(encoder(images[:, 1:])))
    d = torch.linalg.vector_norm(early - late, dim=1, keepdim=True)
    d = F.interpolate(d, size=labels.shape[-2:], mode="bilinear", align_corners=False)[:, 0]
    return d[valid], labels[valid]


def loss_for(d, water):
    dry = d[~water].square()
    wet = (2 - d[water]).clamp_min(0).square()
    return dry.sum() / max(dry.numel(), 1) + wet.sum() / max(wet.numel(), 1)


def batches(tiles):
    for index in range(0, len(tiles), BATCH):
        yield tiles[index:index + BATCH]


@torch.no_grad()
def source_calibration(model, tiles, normalization):
    rng = np.random.default_rng(0)
    distances_sample, validation_labels = [], []
    for tile in tiles:
        d, labels = distances(model, [tile], normalization)
        pick = rng.choice(len(d), min(len(d), 1024), replace=False)
        distances_sample.append(d.cpu().numpy()[pick])
        validation_labels.append(labels.cpu().numpy()[pick])
    d = np.concatenate(distances_sample).astype(np.float64)
    y = np.concatenate(validation_labels).astype(np.float64)
    if not 0 < y.sum() < len(y):
        raise ValueError("Calibration needs both classes")

    def nll(parameters):
        z = d * parameters[0] + parameters[1]
        return float(np.mean(np.logaddexp(0, z) - y * z))

    fit = minimize(nll, [1.0, -1.0], bounds=[(1e-4, 100), (-100, 100)], method="L-BFGS-B")
    if not fit.success or not np.isfinite(fit.x).all():
        raise ValueError(f"Source calibration failed: {fit.message}")
    return {"slope": float(fit.x[0]), "intercept": float(fit.x[1]), "threshold": 0.5,
            "sample_pixels": len(y), "positive_pixels": int(y.sum()),
            "brier": float(np.square(expit(d * fit.x[0] + fit.x[1]) - y).mean())}


def train_seed(seed, samples, normalization, dest):
    torch.manual_seed(seed)
    randomizer = random.Random(seed)
    encoder, attention = load_stanet()
    model = nn.ModuleList((encoder, attention, nn.Dropout2d(0.1))).cuda()
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)
    indices = list(range(len(samples["train"])))
    history, best = [], float("inf")
    checkpoint = dest / "model.pt"
    for epoch in range(1, EPOCHS + 1):
        model.train()
        randomizer.shuffle(indices)
        train_loss = []
        for batch in batches([samples["train"][i] for i in indices]):
            optimizer.zero_grad(set_to_none=True)
            loss = loss_for(*distances(model, batch, normalization))
            if not torch.isfinite(loss):
                raise ValueError(f"Nonfinite training loss at seed {seed} epoch {epoch}")
            loss.backward()
            optimizer.step()
            train_loss.append(loss.detach())
        model.eval()
        with torch.no_grad():
            val = float(torch.stack([loss_for(*distances(model, batch, normalization))
                                     for batch in batches(samples["selection"])]).mean())
        if not np.isfinite(val):
            raise ValueError(f"Nonfinite source selection loss for seed {seed}")
        history.append({"epoch": epoch, "train_loss": float(torch.stack(train_loss).mean()),
                        "selection_loss": val})
        print(f"Seed {seed} {history[-1]}", flush=True)
        if val < best:
            best = val
            torch.save({"model": model.state_dict(), "selected_epoch": epoch, "seed": seed,
                        "normalize": normalization, "stanet_commit": REV}, checkpoint)
    selected = torch.load(checkpoint, weights_only=True)
    model.load_state_dict(selected["model"])
    calibration = source_calibration(model, samples["calibration"], normalization)
    report = {"seed": seed, "selected_epoch": selected["selected_epoch"], "history": history,
              "normalization": normalization, "calibration": calibration,
              "checkpoint_sha256": digest(checkpoint), "plan_sha256": PLAN_SHA256,
              "gpu": torch.cuda.get_device_name(), "torch": torch.__version__}
    (dest / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")


def full_main():
    if not ROOT.is_dir() or not torch.cuda.is_available():
        raise RuntimeError("Full STANet source training requires Kaggle GPU")
    torch.set_num_threads(2)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    output = ROOT / "stanet_source_full"
    output.mkdir()
    samples = source_tiles()
    normalization = train_normalization(samples["train"])
    for seed in SEEDS:
        dest = output / f"seed{seed}"
        dest.mkdir()
        train_seed(seed, samples, normalization, dest)
    (output / "completed.json").write_text(json.dumps({"seeds": SEEDS, "plan_sha256": PLAN_SHA256}), encoding="utf-8")
