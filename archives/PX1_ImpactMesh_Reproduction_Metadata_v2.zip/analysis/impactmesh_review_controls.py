"""Post-hoc, CPU-only inference controls on the frozen ImpactMesh cohort."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace
from zipfile import ZipFile

import numpy as np
from sklearn.metrics import average_precision_score
import torch


REV = Path(__file__).resolve().parents[1]
DATA = REV / "fresh_sar_test"
FROZEN = DATA / "frozen_comparison_v2"
OUT = REV / "generated/isprs_review_20261120"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def illustrate(chip, probability, physical, event):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import ListedColormap
    from matplotlib.patches import Patch
    from tta_px1 import P_LO, P_HI

    label = np.load(FROZEN / "labels" / f"{chip}.npy", allow_pickle=False)
    observed = np.isin(label, [0, 2])
    teacher_water = (probability > P_HI) & event["radar_valid"]
    added = physical & (probability >= P_LO) & (probability <= P_HI)
    fig, axes = plt.subplots(1, 4, figsize=(7.1, 2.3), layout="constrained")
    for ax, title in zip(axes, ("Sentinel-1 VV", "Reference floodwater", "Teacher water targets", "Rule-added targets")):
        ax.set_title(title, fontsize=8)
        ax.set_axis_off()
    axes[0].imshow(event["raw"][0], cmap="gray", vmin=-26, vmax=-4)
    binary = ListedColormap(["#f0f2f3", "#246c9d", "#aab0b4"])
    for ax, mask in zip(axes[1:3], (label == 2, teacher_water)):
        ax.imshow(np.where(observed, mask, 2), cmap=binary, vmin=0, vmax=2)
    colors = ["#f0f2f3", "#246c9d", "#bf4b25", "#aab0b4"]
    axes[3].imshow(np.where(observed, np.where(added, np.where(label == 2, 1, 2), 0), 3),
                   cmap=ListedColormap(colors), vmin=0, vmax=3)
    fig.legend([Patch(facecolor=colors[i]) for i in (1, 2, 3)],
               ["Floodwater / water target", "Addition on reference dry land", "Excluded from scoring"],
               loc="outside lower center", ncols=3, frameon=False, fontsize=7)
    fig.savefig(REV / "paper_wip/figures/fig_impactmesh_review_targets.pdf", bbox_inches="tight")
    plt.close(fig)
    report = dict(chip=chip, seed=0, additions_flood=int((added & (label == 2)).sum()),
                  additions_dry=int((added & (label == 0)).sum()))
    (OUT / "target_illustration.json").write_text(json.dumps(report, indent=2), encoding="utf-8")


def main(example=False, selected=None, threads=6):
    OUT.mkdir(exist_ok=True)
    snapshot = FROZEN / "protocol_snapshot.zip"
    assert sha(snapshot) == (FROZEN / "snapshot.sha256").read_text().split()[0]
    hashes = {key.replace("\\", "/"): value for key, value in read(FROZEN / "freeze.json")["files"].items()}
    stage = OUT / "frozen_code"
    with ZipFile(snapshot) as archive:
        names = [name for name in archive.namelist() if name.startswith("src/") and name.endswith(".py")]
        names.append("revision/fresh_sar_test/experiment.py")
        for name in names:
            dst = stage / name
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(archive.read(name))
    sys.path.insert(0, str(stage / "revision/fresh_sar_test"))
    from experiment import FloodResNet, run_one
    from tta_px1 import adaptive_water_mask, valid_adaptive_dark, P_LO, P_HI

    torch.set_num_threads(threads)
    ref = read(DATA / "source_calibration.json")
    roster = read(DATA / "selected.json")
    inputs = read(DATA / "input_verification.json")
    assert sum(map(len, roster.values())) == 516 and len(roster) == 13
    if selected and not set(selected) <= set(roster):
        raise ValueError("Unknown activation in --events")
    for name in ("source_calibration.json", "selected.json", "input_verification.json"):
        assert sha(DATA / name) == hashes[name]
    checkpoints = [DATA / f"source_models/SSL4EO_seed{seed}/model.pt" for seed in range(3)]
    for checkpoint in checkpoints:
        assert sha(checkpoint) == hashes[checkpoint.relative_to(DATA).as_posix()]
    for event, chips in roster.items():
        if selected and event not in selected:
            continue
        path = OUT / f"{event}.json"
        if example and event != "EMSR795":
            continue
        if not example and path.exists():
            continue
        ev = {name: [] for name in ("raw", "terr", "radar_valid", "terrain_valid")}
        masks = []
        labels = []
        for chip in chips:
            prepared = DATA / "prepared" / f"{chip}.npz"
            label_path = FROZEN / "labels" / f"{chip}.npy"
            assert sha(prepared) == inputs[chip]["input_sha256"]
            assert sha(label_path) == inputs[chip]["label_sha256"]
            label = np.load(label_path, allow_pickle=False)
            keep = (label == 0) | (label == 2)
            masks.append(keep)
            labels.append(label[keep] == 2)
            with np.load(prepared, allow_pickle=False) as chip_data:
                for key, source in zip(ev, ("raw", "terr", "rv", "hv")):
                    ev[key].append(chip_data[source])
        ev["physics_terrain"] = ev["terr"]
        ev["lab"] = [np.full(x.shape[1:], 255, np.uint8) for x in ev["raw"]]
        ev["clean"] = [False] * len(chips)
        y = np.concatenate(labels)
        tv, th = valid_adaptive_dark(ev["raw"], ev["radar_valid"])
        eligible = []
        for raw, terrain, rv, hv in zip(ev["raw"], ev["terr"], ev["radar_valid"], ev["terrain_valid"]):
            t = np.concatenate([terrain, rv[None], hv[None]], axis=0).astype(np.float32)
            eligible.append(adaptive_water_mask(torch.from_numpy(raw[None]), torch.from_numpy(t[None]), tv, th)[0].numpy())
        if example:
            chosen = "EMSR795_6_32TPP_x644215_y4852065"
            idx = chips.index(chosen)

            def capture(i, score):
                if i == idx:
                    illustrate(chosen, score, eligible[i], {key: values[i] for key, values in ev.items()})

            args = SimpleNamespace(seed=0, steps=0, model_factory=FloodResNet, score_observer=capture)
            run_one("adabn_valid", "V0", event, ev, np.float32(ref["mean"]), np.float32(ref["std"]), args, "cpu", str(checkpoints[0]))
            return
        result = {"prevalence": float(y.mean()), "seeds": []}
        for seed, checkpoint in enumerate(checkpoints):
            row = {}
            for method in ("none_valid", "adabn_valid"):
                start = time.perf_counter()
                scores = []
                boosted = []

                def observe(i, score):
                    scores.append(score[masks[i]])
                    if method == "adabn_valid":
                        p = np.where(eligible[i] & (score >= P_LO), np.maximum(score, P_HI), score)
                        boosted.append(p[masks[i]])

                args = SimpleNamespace(seed=seed, steps=0, model_factory=FloodResNet, score_observer=observe)
                run_one(method, "V0", event, ev, np.float32(ref["mean"]), np.float32(ref["std"]), args, "cpu", str(checkpoint))
                seconds = time.perf_counter() - start
                for arm, chips_scores in ((method, scores), ("adabn_physa_valid_post", boosted)):
                    if not chips_scores:
                        continue
                    score = np.concatenate(chips_scores)
                    assert np.isfinite(score).all() and len(score) == len(y)
                    pred = score >= ref["threshold"]
                    tp, fp, fn, tn = (int(np.count_nonzero(a)) for a in (pred & y, pred & ~y, ~pred & y, ~pred & ~y))
                    row[arm] = dict(ap=float(average_precision_score(y, score)),
                                    tp=tp, fp=fp, fn=fn, tn=tn,
                                    score_sha256=hashlib.sha256(score.tobytes()).hexdigest())
                row[method]["cpu_seconds"] = seconds
            result["seeds"].append(row)
            print(event, seed, "inference checked", flush=True)
        with path.open("x", encoding="utf-8") as stream:
            json.dump(result, stream, indent=2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--example", action="store_true")
    parser.add_argument("--events", nargs="+")
    parser.add_argument("--threads", type=int, default=6)
    args = parser.parse_args()
    main(example=args.example, selected=args.events, threads=args.threads)
