"""Verify downloaded full STANet source checkpoints and calibration reports."""

import argparse
import hashlib
import json
import math
from pathlib import Path

import torch


COMMIT = "6152d72f55df00a43d341580970be7a58c6b0cd5"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def verify(folder, plan_path):
    plan = load(plan_path)
    plan_sha = sha(plan_path)
    seeds = plan["seeds"]
    completion = load(folder / "completed.json")
    require(completion == {"seeds": seeds, "plan_sha256": plan_sha}, "Completion marker does not match plan")
    rows = []
    for seed in seeds:
        dest = folder / f"seed{seed}"
        report = load(dest / "report.json")
        checkpoint = dest / "model.pt"
        checksum = sha(checkpoint)
        require(checksum == report["checkpoint_sha256"], f"Checkpoint hash mismatch for seed {seed}")
        require(report["seed"] == seed and report["plan_sha256"] == plan_sha,
                f"Run provenance mismatch for seed {seed}")
        history = report["history"]
        require([row["epoch"] for row in history] == list(range(1, plan["epochs_per_seed"] + 1)),
                f"Incomplete training history for seed {seed}")
        require(all(math.isfinite(row[key]) and row[key] >= 0 for row in history
                    for key in ("train_loss", "selection_loss")), f"Invalid loss for seed {seed}")
        best = min(history, key=lambda row: row["selection_loss"])
        require(report["selected_epoch"] == best["epoch"], f"Wrong selected epoch for seed {seed}")
        state = torch.load(checkpoint, map_location="cpu", weights_only=True)
        require(state["seed"] == seed and state["stanet_commit"] == COMMIT
                and state["selected_epoch"] == best["epoch"]
                and list(state["normalize"]) == report["normalization"], f"Checkpoint metadata mismatch for seed {seed}")
        parameters = state["model"]
        require(all(isinstance(tensor, torch.Tensor) and torch.isfinite(tensor).all().item()
                    for tensor in parameters.values()) and all(any(key.startswith(prefix) for key in parameters)
                                                             for prefix in ("0.", "1.")),
                f"Invalid STANet state dict for seed {seed}")
        mean, std = report["normalization"]
        require(math.isfinite(mean) and math.isfinite(std) and std > 0, f"Invalid normalization for seed {seed}")
        calibration = report["calibration"]
        slope, intercept = calibration["slope"], calibration["intercept"]
        require(math.isfinite(slope) and math.isfinite(intercept) and slope > 0
                and calibration["threshold"] == 0.5 and 0 <= calibration["brier"] <= 1
                and 0 < calibration["positive_pixels"] < calibration["sample_pixels"],
                f"Invalid probability calibration report for seed {seed}")
        prevalence = calibration["positive_pixels"] / calibration["sample_pixels"]
        rows.append({"seed": seed, "selected_epoch": best["epoch"], "best_selection_loss": best["selection_loss"],
                     "checkpoint_sha256": checksum, "calibration": calibration,
                     "constant_prevalence_brier": prevalence * (1 - prevalence),
                     "effective_distance_threshold": -intercept / slope, "gpu": report["gpu"],
                     "torch": report["torch"], "normalization": report["normalization"]})
    require(len({row["checkpoint_sha256"] for row in rows}) == len(seeds), "Identical seed checkpoints")
    require(len({tuple(row["normalization"]) for row in rows}) == 1, "Inconsistent shared normalization")
    require(len({(row["calibration"]["positive_pixels"], row["calibration"]["sample_pixels"]) for row in rows}) == 1,
            "Seeds calibrated on different source pixels")
    return {"status": "passed", "plan_sha256": plan_sha, "seeds": rows,
            "calibration_check": "report consistency and bounds; no pixel scores were archived for recomputation"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("plan", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(2)
    report = verify(args.folder, args.plan)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
