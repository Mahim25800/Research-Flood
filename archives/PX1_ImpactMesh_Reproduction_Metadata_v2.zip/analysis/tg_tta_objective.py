"""Terrain-risk and loss terms from Song and Lee (2026), equations 7–9."""

import torch


def terrain_risk(hand, slope, valid, *, epsilon):
    """Scale HAND (metres) and slope (degrees) across one complete scene."""
    if hand.shape != slope.shape or valid.shape != hand.shape or valid.dtype != torch.bool:
        raise ValueError("HAND, slope and the boolean validity mask must share a grid")
    if not epsilon > 0 or not valid.any():
        raise ValueError("Terrain scaling requires positive epsilon and valid scene pixels")
    scaled = []
    for layer in (hand, slope):
        values = layer[valid].float()
        if not torch.isfinite(values).all() or (values < 0).any():
            raise ValueError("Valid terrain values must be finite and nonnegative")
        logged = torch.log1p(values)
        low, high = torch.quantile(logged, logged.new_tensor([0.05, 0.95]))
        scaled.append(((logged - low) / (high - low + epsilon)).clamp(0, 1))
    risk = torch.zeros_like(hand, dtype=torch.float32)
    risk[valid] = torch.maximum(*scaled)
    return risk


def tg_tta_loss(student, teacher, risk, radar_valid, terrain_valid, *, gate_c):
    """Compute the weighted loss on tiled probabilities shaped [batch, height, width]."""
    if student.ndim != 3 or any(x.shape != student.shape for x in (teacher, risk, radar_valid, terrain_valid)):
        raise ValueError("Student, teacher, terrain and masks must share a [batch, height, width] grid")
    if radar_valid.dtype != torch.bool or terrain_valid.dtype != torch.bool:
        raise ValueError("Validity masks must be boolean")
    if not gate_c > 0 or not radar_valid.any():
        raise ValueError("Loss requires a positive teacher gate coefficient and valid radar pixels")
    teacher = teacher.detach()
    fidelity = (student[radar_valid] - teacher[radar_valid]).square().mean()

    topo_valid = radar_valid & terrain_valid
    penalty = student[topo_valid] * risk[topo_valid] * torch.exp(-gate_c * teacher[topo_valid])
    topo = penalty.sum() / max(penalty.numel(), 1)

    horizontal = radar_valid[:, :, 1:] & radar_valid[:, :, :-1]
    vertical = radar_valid[:, 1:, :] & radar_valid[:, :-1, :]
    dx = (student[:, :, 1:] - student[:, :, :-1])[horizontal].abs()
    dy = (student[:, 1:, :] - student[:, :-1, :])[vertical].abs()
    smooth = dx.sum() / max(dx.numel(), 1) + dy.sum() / max(dy.numel(), 1)
    return 3 * fidelity + 3 * topo + 0.1 * smooth
