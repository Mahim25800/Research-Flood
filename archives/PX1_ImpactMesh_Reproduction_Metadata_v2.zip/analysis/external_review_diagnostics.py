"""Generate exploratory plots and checks from archived external scores."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import wilcoxon

from impactmesh_saved_scores import ARMS, ROOT, RUN, REVISION, digest, read_json


PAPER = REVISION / "paper_wip"
OUT = REVISION / "generated/isprs_review_20261120"
GEOID = REVISION / "generated/geoid_v4_results_20261118/geoid_evaluation_v4/results/results.json"
RECALL = np.linspace(.01, 1, 100)


def precision_on_grid(negative, positive):
    tp = np.cumsum(positive[::-1])
    fp = np.cumsum(negative[::-1])
    levels = np.searchsorted(tp, RECALL * tp[-1])
    return tp[levels] / (tp[levels] + fp[levels])


def impactmesh(data):
    curves = []
    inputs = read_json(ROOT / "input_verification.json")
    for event, chips in read_json(ROOT / "selected.json").items():
        hist = np.zeros((2, 2, 1000), dtype=np.int64)
        masks = []
        labels = []
        for chip in chips:
            path = RUN / "labels" / (chip + ".npy")
            assert digest(path) == inputs[chip]["label_sha256"]
            lab = np.load(path, allow_pickle=False)
            keep = (lab == 0) | (lab == 2)
            masks.append(keep)
            labels.append(lab[keep] == 2)
        assert np.isclose(sum(x.sum() for x in labels) / sum(len(x) for x in labels),
                          data[event]["flood_fraction"])
        seed_curves = []
        for seed in range(3):
            hist.fill(0)
            folder = RUN / event / str(seed)
            hashes = read_json(folder / "scores.json")
            for chip, keep, positive in zip(chips, masks, labels):
                for i, arm in enumerate(ARMS):
                    name = Path(arm) / (chip + ".npy")
                    assert digest(folder / name) == hashes[str(name)]
                    score = np.load(folder / name, allow_pickle=False)[keep]
                    bins = np.minimum((score * 1000).astype(np.int32), 999)
                    hist[i, 0] += np.bincount(bins[~positive], minlength=1000)
                    hist[i, 1] += np.bincount(bins[positive], minlength=1000)
            seed_curves.append([precision_on_grid(*counts) for counts in hist])
        curves.append(np.mean(seed_curves, axis=0))
    return np.mean(curves, axis=0)


def main():
    OUT.mkdir(exist_ok=True)
    saved = read_json(REVISION / "analysis/impactmesh_saved_scores.json")["events"]
    geoid = read_json(GEOID)["events"]
    assert len(saved) == 13 and len(geoid) == 9
    points = {"ImpactMesh": [], "GEOID-Flood": []}
    geoid_curves = []
    for event, data in geoid.items():
        per_seed, curves = [], []
        for seed in range(3):
            ordinary, physics = (data["methods"][f"{seed}:{arm}"]["flood"] for arm in ARMS)
            negative, positive = map(np.asarray, ordinary["histogram"])
            physics_negative, physics_positive = map(np.asarray, physics["histogram"])
            assert (negative.sum(), positive.sum()) == (physics_negative.sum(), physics_positive.sum())
            counts = ordinary["source_only"]
            per_seed.append([counts["fn"] / positive.sum(), positive.sum() / (negative.sum() + positive.sum()),
                             physics["ap"] - ordinary["ap"]])
            curves.append([precision_on_grid(negative, positive),
                           precision_on_grid(physics_negative, physics_positive)])
        points["GEOID-Flood"].append(dict(event=event, values=np.mean(per_seed, axis=0).tolist()))
        geoid_curves.append(np.mean(curves, axis=0))
    for event, row in saved.items():
        ordinary, physics = (row[key] for key in ARMS)
        points["ImpactMesh"].append(dict(event=event, values=[ordinary["miss"], row["flood_fraction"],
                                                             physics["ap"] - ordinary["ap"]]))

    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9), sharey=True, layout="constrained")
    for i, ax in enumerate(axes):
        ax.axhline(0, color="#9a9a9a", linewidth=.7)
        for cohort, marker, colour in (("ImpactMesh", "o", "#aa4927"), ("GEOID-Flood", "s", "#305e87")):
            values = 100 * np.array([row["values"] for row in points[cohort]])
            ax.scatter(values[:, i], values[:, 2], label=cohort, marker=marker, color=colour)
        ax.set_xlabel(("Ordinary self-training miss rate (%)", "Reference floodwater prevalence (%)")[i])
    axes[0].set_ylabel("Physics increment in AP (points)")
    axes[0].legend(frameon=False, fontsize=8)
    fig.savefig(PAPER / "figures/fig_external_review_events.pdf", bbox_inches="tight")
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9), sharey=True, layout="constrained")
    for ax, title, curves in zip(axes, ("ImpactMesh", "GEOID-Flood"),
                                 (impactmesh(saved), np.mean(geoid_curves, axis=0))):
        for label, colour, values in zip(("Ordinary self-training", "Physics-guided"),
                                         ("#305e87", "#aa4927"), curves):
            ax.plot(100 * RECALL, 100 * values, color=colour, label=label)
        ax.set(title=title, xlabel="Recall (%)", ylim=(0, 100), xlim=(0, 100))
    axes[0].set_ylabel("Mean precision (%)")
    axes[0].legend(frameon=False, fontsize=8, loc="lower left")
    fig.savefig(PAPER / "figures/fig_external_review_pr.pdf", bbox_inches="tight")
    plt.close(fig)

    delta = [r["values"][2] for r in points["ImpactMesh"]]
    test = wilcoxon(delta, method="exact", alternative="two-sided")
    (OUT / "diagnostics.json").write_text(
        json.dumps(dict(points=points, wilcoxon_two_sided_p=test.pvalue), indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
