"""Run the matched paired-input TG-TTA study on a private Kaggle GPU."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
from urllib.request import urlretrieve
from zipfile import ZipFile

import numpy as np
from sklearn.metrics import average_precision_score
import torch
from torch import nn
from torch.nn import functional as F


ARCHIVE = "px1_impactmesh_tg_tta_inputs.zip"
ARMS = ("source", "ordinary", "tg_tta", "physics_vv", "physics_vv_vh")


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def inputs(mount, scratch, protocol):
    archives = list(mount.rglob(ARCHIVE))
    if archives:
        if len(archives) != 1 or sha(archives[0]) != protocol["archive_sha256"]:
            raise ValueError("ImpactMesh archive failed verification")
        with ZipFile(archives[0]) as bundle:
            bundle.extractall(scratch)
        root = scratch
    else:
        roots = [p.parent for p in mount.rglob("inputs.json")
                 if sha(p) == protocol["input_manifest_sha256"]]
        if len(roots) != 1:
            raise ValueError("Could not identify verified ImpactMesh inputs")
        root = roots[0]
    if sha(root / "inputs.json") != protocol["input_manifest_sha256"]:
        raise ValueError("Input manifest hash mismatch")
    return root, json.loads((root / "inputs.json").read_text())


def make_model(scratch, protocol):
    package = scratch / "stanet_upstream"
    package.mkdir()
    (package / "__init__.py").touch()
    for path, expected in protocol["stanet_files"].items():
        url = f"https://raw.githubusercontent.com/justchenhao/STANet/{protocol['stanet_commit']}/models/{path}"
        urlretrieve(url, package / path)
        if sha(package / path) != expected:
            raise ValueError(f"Upstream source hash mismatch: {path}")
    sys.path.insert(0, str(scratch))
    from stanet_upstream.backbone import CDSA, define_F

    return nn.ModuleList((define_F(in_c=1, f_c=64, type="mynet3"),
                          CDSA(in_c=64, ds=4, mode="BAM"), nn.Dropout2d(0.1))).cuda().eval()


def logits(model, pairs, calibration):
    encoder, attention, dropout = model
    a, b = attention(dropout(encoder(pairs[:, :1])), dropout(encoder(pairs[:, 1:])))
    distance = torch.linalg.vector_norm(a - b, dim=1, keepdim=True)
    distance = F.interpolate(distance, size=pairs.shape[-2:], mode="bilinear", align_corners=False)[:, 0]
    return distance * calibration["slope"] + calibration["intercept"]


def event_inputs(root, roster, pins, normalize):
    rows = {key: [] for key in ("pre", "event", "valid", "terrain_valid", "hand", "slope")}
    for chip in roster:
        path = root / "pairs" / f"{chip}.npz"
        if sha(path) != pins[chip]:
            raise ValueError(f"Input hash mismatch: {chip}")
        with np.load(path, allow_pickle=False) as data:
            for key in rows:
                rows[key].append(data[key])
    arrays = {key: np.stack(values) for key, values in rows.items()}
    valid = arrays["valid"]
    radar = np.stack((arrays["pre"], arrays["event"][:, 0]), axis=1)
    mean, std = normalize
    pairs = np.where(valid[:, None], (np.clip(radar, -23, 0) - mean) / std, 0).astype(np.float32, copy=False)
    if pairs.shape != (len(roster), 2, 256, 256) or not np.isfinite(pairs).all():
        raise ValueError("Invalid paired model input")
    return (torch.as_tensor(pairs, device="cuda"), arrays["event"],
            *(torch.as_tensor(arrays[key], device="cuda") for key in ("valid", "terrain_valid", "hand", "slope")))


def darkness_threshold(radar, valid, cap):
    samples = np.concatenate([r.ravel()[::7][v.ravel()[::7]] for r, v in zip(radar, valid)])
    if not samples.size or not np.isfinite(samples).all():
        raise ValueError("No finite event radar for the darkness threshold")
    hist, edges = np.histogram(samples, bins=256)
    centers = (edges[:-1] + edges[1:]) / 2
    left = np.cumsum(hist)
    right = left[-1] - left
    weighted = np.cumsum(hist * centers)
    mean_left = weighted / np.maximum(left, 1)
    mean_right = (weighted[-1] - weighted) / np.maximum(right, 1)
    index = int(np.argmax(left * right * (mean_left - mean_right)**2))
    return min(cap, float((centers[index] + mean_left[index]) / 2))


@torch.no_grad()
def inference(model, pairs, calibration, mc_passes=0):
    model.eval()
    model[2].train(bool(mc_passes))
    outputs = []
    for batch in pairs.split(2):
        outputs.append(torch.stack([logits(model, batch, calibration).sigmoid()
                                    for _ in range(mc_passes or 1)]).mean(0))
    model.eval()
    return torch.cat(outputs)


def predict_event(model, data, calibration, protocol, seed, activation):
    pairs, radar, valid, terrain_valid, hand, slope = data
    rng_seed = seed * 100000 + int(activation.removeprefix("EMSR"))
    torch.manual_seed(rng_seed)
    sample = np.random.default_rng(rng_seed).integers(len(pairs), size=(protocol["steps"], 2))
    teacher = inference(model, pairs, calibration, protocol["teacher_passes"])
    scores = {"source": inference(model, pairs, calibration).cpu().numpy()}
    dry, wet = teacher < 0.1, teacher > 0.9
    eligible = terrain_valid & valid & (hand < 5) & (slope < 3)
    vv = darkness_threshold(radar[:, 0], valid.cpu().numpy(), -15)
    vh = darkness_threshold(radar[:, 1], valid.cpu().numpy(), -22)
    radar = torch.as_tensor(radar, device="cuda")
    cue = eligible & (radar[:, 0] < vv)
    dual = cue & (radar[:, 1] < vh)
    risk = terrain_risk(hand, slope, terrain_valid, epsilon=protocol["epsilon"])
    diagnostics = {"vv_cutoff_db": vv, "vh_cutoff_db": vh, "arms": {}}
    for arm in ARMS[1:]:
        student = deepcopy(model).eval()
        optimizer = torch.optim.Adam(student.parameters(), lr=protocol["lr"])
        anchor = {"physics_vv": cue, "physics_vv_vh": dual}.get(arm)
        hard_wet, hard_dry = wet, dry
        if anchor is not None:
            hard_wet = wet | (anchor & ~dry)
            hard_dry = dry & ~anchor
        updates = 0
        for batch in sample:
            idx = torch.as_tensor(batch, device="cuda")
            if arm == "tg_tta":
                prediction = logits(student, pairs[idx], calibration).sigmoid()
                loss = tg_tta_loss(prediction, teacher[idx], risk[idx], valid[idx], terrain_valid[idx],
                                   gate_c=protocol["gate_c"])
            else:
                use = valid[idx] & (hard_wet[idx] | hard_dry[idx])
                if not use.any():
                    continue
                target = hard_wet[idx][use].float()
                pred = logits(student, pairs[idx], calibration)[use]
                weights = 1 + 2 * target
                loss = F.binary_cross_entropy_with_logits(pred, target, weight=weights, reduction="sum") / weights.sum()
            if not torch.isfinite(loss):
                raise ValueError(f"Nonfinite loss: {activation}/{seed}/{arm}")
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            updates += 1
        diagnostics["arms"][arm] = {"updates": updates, "added_wet": int((valid & hard_wet & ~wet).sum())}
        scores[arm] = inference(student, pairs, calibration).cpu().numpy()
    if not all(np.isfinite(score).all() and score.min() >= 0 and score.max() <= 1 for score in scores.values()):
        raise ValueError("Invalid prediction probabilities")
    return scores, diagnostics


def metrics(values, target):
    pred = values >= 0.5
    tp, fp, fn, tn = (int(x.sum()) for x in (pred & target, pred & ~target, ~pred & target, ~pred & ~target))
    return {"ap": float(average_precision_score(target, values)), "miss": fn / (tp + fn),
            "fpr": fp / (fp + tn), "tp": tp, "fp": fp, "fn": fn, "tn": tn}


def score_event(root, destination, chips, label_pins, predictions):
    labels = []
    for chip in chips:
        path = root / "labels" / f"{chip}.npy"
        if sha(path) != label_pins[chip]:
            raise ValueError(f"Label hash mismatch: {chip}")
        labels.append(np.load(path, allow_pickle=False))
    labels = np.stack(labels)
    keep = (labels == 0) | (labels == 2)
    target = labels[keep] == 2
    if not 0 < target.sum() < target.size:
        raise ValueError("Scoring requires both classes")
    arms = {}
    for arm, full in predictions.items():
        saved = full[keep]
        path = destination / f"{arm}.npz"
        np.savez_compressed(path, scores=saved)
        arms[arm] = {**metrics(saved, target), "score_sha256": sha(path)}
    return arms


def run(protocol, protocol_sha256):
    mount, work = Path("/kaggle/input"), Path("/kaggle/working")
    if not mount.is_dir() or not torch.cuda.is_available():
        raise RuntimeError("This comparison requires Kaggle GPU")
    torch.set_num_threads(2)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    scratch = Path("/tmp/px1_impactmesh_tg_tta")
    scratch.mkdir()
    root, spec = inputs(mount, scratch, protocol)
    if len(spec["events"]) != 13 or sum(map(len, spec["events"].values())) != 516:
        raise ValueError("Unexpected ImpactMesh cohort")
    model = make_model(scratch, protocol)
    output = work / "impactmesh_tg_tta"
    output.mkdir()
    write(output / "run.json", {"protocol_sha256": protocol_sha256, "gpu": torch.cuda.get_device_name(),
                               "torch": torch.__version__, "seeds": [0, 1, 2]})
    for seed in (0, 1, 2):
        reference = spec["source"][str(seed)]
        path = root / "checkpoints" / f"seed{seed}.pt"
        if sha(path) != reference["checkpoint_sha256"]:
            raise ValueError(f"Checkpoint mismatch: {seed}")
        state = torch.load(path, map_location="cpu", weights_only=True)
        if state["seed"] != seed or state["stanet_commit"] != protocol["stanet_commit"]:
            raise ValueError("Checkpoint metadata mismatch")
        if state["selected_epoch"] != reference["selected_epoch"] or list(state["normalize"]) != reference["normalization"]:
            raise ValueError("Checkpoint calibration provenance mismatch")
        model.load_state_dict(state["model"])
        for event, roster in spec["events"].items():
            dest = output / f"seed{seed}" / event
            dest.mkdir(parents=True)
            data = event_inputs(root, roster, spec["input"], state["normalize"])
            predictions, details = predict_event(model, data, reference["calibration"], protocol, seed, event)
            arms = score_event(root, dest, roster, spec["label"], predictions)
            write(dest / "results.json", {"activation": event, "seed": seed, "arms": arms, "diagnostics": details})
            print(f"Completed seed {seed} {event}", flush=True)
    write(output / "completed.json", {"pairs": 39, "protocol_sha256": protocol_sha256})
